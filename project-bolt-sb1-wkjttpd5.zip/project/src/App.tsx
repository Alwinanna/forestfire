import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster } from 'react-hot-toast';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { Dashboard } from './components/Dashboard';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { NotificationProvider } from './contexts/NotificationContext';

function AppContent() {
  const { user, loading } = useAuth();
  const [showSplash, setShowSplash] = useState(true);
  const [currentScreen, setCurrentScreen] = useState<'splash' | 'login' | 'dashboard'>('splash');

  // Handle splash screen timing
  useEffect(() => {
    const splashTimer = setTimeout(() => {
      setShowSplash(false);
      setCurrentScreen('login');
    }, 4000); // Show splash for 4 seconds

    return () => clearTimeout(splashTimer);
  }, []);

  // Handle user authentication state
  useEffect(() => {
    if (!loading && user && !showSplash) {
      setCurrentScreen('dashboard');
    } else if (!loading && !user && !showSplash) {
      setCurrentScreen('login');
    }
  }, [user, loading, showSplash]);

  if (loading && !showSplash) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="w-20 h-20 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
          <h2 className="text-3xl font-bold text-white mb-3">संजीवनी • Sanjeevani</h2>
          <p className="text-slate-400">AI Models & Satellite Data Loading...</p>
          <div className="mt-4 text-sm text-slate-500">
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              ISRO Satellite Connection
            </div>
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
              Weather Station Networks
            </div>
            <div className="flex items-center justify-center gap-2">
              <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
              ML Model Initialization
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      {currentScreen === 'splash' && (
        <motion.div
          key="splash"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.1 }}
          transition={{ duration: 0.8 }}
        >
          <SplashScreen />
        </motion.div>
      )}
      
      {currentScreen === 'login' && (
        <motion.div
          key="login"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.6 }}
        >
          <LoginScreen />
        </motion.div>
      )}
      
      {currentScreen === 'dashboard' && (
        <motion.div
          key="dashboard"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.6 }}
        >
          <Dashboard />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
          <AppContent />
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 6000,
              style: {
                background: '#1e293b',
                color: '#f1f5f9',
                border: '1px solid #334155',
                fontSize: '14px',
                fontWeight: '500'
              },
            }}
          />
        </div>
      </NotificationProvider>
    </AuthProvider>
  );
}

export default App;