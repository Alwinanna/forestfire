import { FireRiskData, AlertData, PopulationImpact, FireSpreadPrediction } from '../types';

// Uttarakhand coordinates and real locations
export const uttarakhandRegions: FireRiskData[] = [
  {
    id: 'nainital-1',
    lat: 29.3919,
    lng: 79.4542,
    riskLevel: 'critical',
    confidence: 94,
    temperature: 32,
    humidity: 15,
    windSpeed: 25,
    windDirection: 45,
    vegetation: 85,
    slope: 35,
    humanActivity: 70,
    lastUpdated: new Date(),
    shapExplanation: {
      topFactors: [
        { factor: 'Low Humidity', impact: 0.35, description: 'Extremely dry conditions (15%) increase fire risk' },
        { factor: 'High Wind Speed', impact: 0.28, description: 'Strong winds (25 km/h) accelerate fire spread' },
        { factor: 'Dense Vegetation', impact: 0.22, description: 'High fuel load (85%) provides combustible material' },
        { factor: 'Human Activity', impact: 0.15, description: 'Tourist activity and road access increase ignition risk' }
      ],
      riskScore: 0.94
    }
  },
  {
    id: 'dehradun-1',
    lat: 30.3165,
    lng: 78.0322,
    riskLevel: 'high',
    confidence: 87,
    temperature: 29,
    humidity: 22,
    windSpeed: 18,
    windDirection: 90,
    vegetation: 78,
    slope: 25,
    humanActivity: 85,
    lastUpdated: new Date(),
    shapExplanation: {
      topFactors: [
        { factor: 'Urban Interface', impact: 0.32, description: 'High human activity (85%) near forest areas' },
        { factor: 'Moderate Vegetation', impact: 0.28, description: 'Significant fuel load in surrounding areas' },
        { factor: 'Low Humidity', impact: 0.25, description: 'Dry conditions favor fire ignition' },
        { factor: 'Temperature', impact: 0.15, description: 'Elevated temperature increases fire probability' }
      ],
      riskScore: 0.87
    }
  },
  {
    id: 'haridwar-1',
    lat: 29.9457,
    lng: 78.1642,
    riskLevel: 'moderate',
    confidence: 72,
    temperature: 27,
    humidity: 35,
    windSpeed: 12,
    windDirection: 180,
    vegetation: 45,
    slope: 15,
    humanActivity: 60,
    lastUpdated: new Date(),
    shapExplanation: {
      topFactors: [
        { factor: 'Human Activity', impact: 0.30, description: 'Moderate human presence increases ignition sources' },
        { factor: 'Vegetation Density', impact: 0.25, description: 'Moderate fuel availability' },
        { factor: 'Wind Conditions', impact: 0.25, description: 'Light winds reduce spread risk' },
        { factor: 'Humidity', impact: 0.20, description: 'Higher humidity (35%) reduces fire risk' }
      ],
      riskScore: 0.72
    }
  }
];

export const currentAlerts: AlertData[] = [
  {
    id: 'alert-001',
    level: 'emergency',
    location: 'Nainital Forest Reserve',
    message: 'CRITICAL: High fire risk detected. Immediate evacuation recommended for 2,847 residents.',
    timestamp: new Date(),
    acknowledged: false,
    estimatedImpact: {
      estimatedAffected: 2847,
      settlements: 12,
      infrastructure: [
        { type: 'Schools', count: 3, risk: 'high' },
        { type: 'Hospitals', count: 1, risk: 'critical' },
        { type: 'Tourist Lodges', count: 8, risk: 'high' },
        { type: 'Roads', count: 5, risk: 'moderate' }
      ],
      evacuationTime: 45,
      safeZones: [
        { lat: 29.4019, lng: 79.4642, capacity: 1500 },
        { lat: 29.3819, lng: 79.4442, capacity: 1000 },
        { lat: 29.4119, lng: 79.4342, capacity: 800 }
      ]
    },
    predictions: [
      { timeHour: 1, affectedArea: 2.5, populationAtRisk: 847, estimatedCasualties: { min: 0, max: 3, mostLikely: 1 }, spreadDirection: 45, intensity: 85 },
      { timeHour: 2, affectedArea: 5.2, populationAtRisk: 1456, estimatedCasualties: { min: 1, max: 8, mostLikely: 3 }, spreadDirection: 52, intensity: 78 },
      { timeHour: 3, affectedArea: 8.7, populationAtRisk: 2134, estimatedCasualties: { min: 2, max: 12, mostLikely: 5 }, spreadDirection: 48, intensity: 72 },
      { timeHour: 6, affectedArea: 15.3, populationAtRisk: 2847, estimatedCasualties: { min: 4, max: 18, mostLikely: 8 }, spreadDirection: 55, intensity: 65 },
      { timeHour: 12, affectedArea: 28.9, populationAtRisk: 4523, estimatedCasualties: { min: 8, max: 25, mostLikely: 14 }, spreadDirection: 60, intensity: 58 }
    ]
  }
];

export const weatherData = {
  current: {
    temperature: 32,
    humidity: 15,
    windSpeed: 25,
    windDirection: 45,
    pressure: 1013,
    visibility: 8
  },
  forecast: [
    { hour: 1, temp: 33, humidity: 14, windSpeed: 27 },
    { hour: 2, temp: 34, humidity: 13, windSpeed: 29 },
    { hour: 3, temp: 35, humidity: 12, windSpeed: 31 },
    { hour: 6, temp: 36, humidity: 11, windSpeed: 28 },
    { hour: 12, temp: 34, humidity: 18, windSpeed: 22 }
  ]
};