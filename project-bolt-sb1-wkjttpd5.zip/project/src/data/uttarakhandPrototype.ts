import { FireRiskData, AlertData } from '../types';

// Focused on Jim Corbett National Park and surrounding areas - high fire risk zone
export const jimCorbettRegion: FireRiskData[] = [
  {
    id: 'jim-corbett-core',
    lat: 29.5319,
    lng: 78.7718,
    riskLevel: 'critical',
    confidence: 96,
    temperature: 34,
    humidity: 12,
    windSpeed: 28,
    windDirection: 65,
    vegetation: 92,
    slope: 45,
    humanActivity: 85, // High due to tourism
    lastUpdated: new Date(),
    shapExplanation: {
      topFactors: [
        { factor: 'Extreme Dryness', impact: 0.38, description: 'Humidity at critical 12% - tinder dry conditions' },
        { factor: 'Dense Sal Forest', impact: 0.32, description: '92% vegetation cover with highly flammable Sal trees' },
        { factor: 'Tourist Activity', impact: 0.18, description: 'High human presence increases ignition sources' },
        { factor: 'Strong Winds', impact: 0.12, description: 'Gusty winds will rapidly spread any fire' }
      ],
      riskScore: 0.96
    }
  },
  {
    id: 'ramnagar-buffer',
    lat: 29.3947,
    lng: 79.1314,
    riskLevel: 'high',
    confidence: 89,
    temperature: 32,
    humidity: 18,
    windSpeed: 22,
    windDirection: 45,
    vegetation: 78,
    slope: 25,
    humanActivity: 95, // Very high - town area
    lastUpdated: new Date(),
    shapExplanation: {
      topFactors: [
        { factor: 'Urban-Forest Interface', impact: 0.35, description: 'Town directly adjacent to forest creates high risk' },
        { factor: 'Agricultural Burning', impact: 0.28, description: 'Farmers burning crop residue nearby' },
        { factor: 'Power Lines', impact: 0.22, description: 'Electrical infrastructure through forest areas' },
        { factor: 'Low Humidity', impact: 0.15, description: 'Dry conditions favor fire spread' }
      ],
      riskScore: 0.89
    }
  },
  {
    id: 'kaladhungi-forest',
    lat: 29.2833,
    lng: 79.0833,
    riskLevel: 'high',
    confidence: 91,
    temperature: 33,
    humidity: 14,
    windSpeed: 25,
    windDirection: 90,
    vegetation: 85,
    slope: 35,
    humanActivity: 70,
    lastUpdated: new Date(),
    shapExplanation: {
      topFactors: [
        { factor: 'Chir Pine Dominance', impact: 0.34, description: 'Highly flammable Chir Pine needles create fire ladder' },
        { factor: 'Steep Terrain', impact: 0.28, description: 'Fire spreads rapidly uphill on 35° slopes' },
        { factor: 'Dry Conditions', impact: 0.24, description: 'Low humidity creates perfect fire conditions' },
        { factor: 'Wind Exposure', impact: 0.14, description: 'Ridge location exposed to strong winds' }
      ],
      riskScore: 0.91
    }
  },
  {
    id: 'nainital-kumaon',
    lat: 29.3919,
    lng: 79.4542,
    riskLevel: 'critical',
    confidence: 94,
    temperature: 31,
    humidity: 16,
    windSpeed: 24,
    windDirection: 120,
    vegetation: 88,
    slope: 40,
    humanActivity: 90, // Very high tourism
    lastUpdated: new Date(),
    shapExplanation: {
      topFactors: [
        { factor: 'Tourist Pressure', impact: 0.36, description: 'Massive tourist influx creates multiple ignition sources' },
        { factor: 'Oak-Pine Mix', impact: 0.29, description: 'Mixed forest with high fuel load and fire ladders' },
        { factor: 'Water Stress', impact: 0.21, description: 'Trees stressed from low rainfall, more flammable' },
        { factor: 'Hill Station Effect', impact: 0.14, description: 'Altitude and wind patterns increase fire risk' }
      ],
      riskScore: 0.94
    }
  },
  {
    id: 'almora-ridge',
    lat: 29.5971,
    lng: 79.6593,
    riskLevel: 'moderate',
    confidence: 76,
    temperature: 28,
    humidity: 25,
    windSpeed: 18,
    windDirection: 180,
    vegetation: 65,
    slope: 30,
    humanActivity: 60,
    lastUpdated: new Date(),
    shapExplanation: {
      topFactors: [
        { factor: 'Terraced Agriculture', impact: 0.32, description: 'Agricultural fires can spread to forest patches' },
        { factor: 'Moderate Vegetation', impact: 0.28, description: 'Mixed agriculture-forest creates fire breaks' },
        { factor: 'Human Settlement', impact: 0.25, description: 'Villages create both risk and fire breaks' },
        { factor: 'Better Humidity', impact: 0.15, description: 'Higher humidity reduces immediate fire risk' }
      ],
      riskScore: 0.76
    }
  }
];

export const corbettEmergencyAlert: AlertData = {
  id: 'corbett-emergency-001',
  level: 'emergency',
  location: 'Jim Corbett National Park - Core Zone',
  message: 'EXTREME FIRE DANGER: Critical conditions detected in core tiger habitat. Immediate closure of all tourist activities and wildlife evacuation protocols activated.',
  timestamp: new Date(),
  acknowledged: false,
  estimatedImpact: {
    estimatedAffected: 4500, // Tourists + staff + nearby villages
    settlements: 8,
    infrastructure: [
      { type: 'Forest Rest Houses', count: 12, risk: 'critical' },
      { type: 'Wildlife Watchtowers', count: 25, risk: 'critical' },
      { type: 'Tourist Lodges', count: 45, risk: 'high' },
      { type: 'Research Stations', count: 3, risk: 'critical' },
      { type: 'Elephant Camps', count: 2, risk: 'critical' }
    ],
    evacuationTime: 90, // Longer due to wildlife considerations
    safeZones: [
      { lat: 29.5500, lng: 78.8000, capacity: 2000 }, // Ramnagar town
      { lat: 29.4800, lng: 78.7200, capacity: 1500 }, // Dhikala evacuation point
      { lat: 29.5800, lng: 78.8200, capacity: 1000 }  // Emergency camp
    ]
  },
  predictions: [
    { 
      timeHour: 1, 
      affectedArea: 3.2, 
      populationAtRisk: 1200, 
      estimatedCasualties: { min: 0, max: 2, mostLikely: 0 }, 
      spreadDirection: 65, 
      intensity: 92 
    },
    { 
      timeHour: 2, 
      affectedArea: 7.8, 
      populationAtRisk: 2100, 
      estimatedCasualties: { min: 1, max: 5, mostLikely: 2 }, 
      spreadDirection: 70, 
      intensity: 88 
    },
    { 
      timeHour: 3, 
      affectedArea: 12.5, 
      populationAtRisk: 2800, 
      estimatedCasualties: { min: 2, max: 8, mostLikely: 4 }, 
      spreadDirection: 68, 
      intensity: 85 
    },
    { 
      timeHour: 6, 
      affectedArea: 25.7, 
      populationAtRisk: 4200, 
      estimatedCasualties: { min: 5, max: 15, mostLikely: 8 }, 
      spreadDirection: 72, 
      intensity: 78 
    },
    { 
      timeHour: 12, 
      affectedArea: 48.3, 
      populationAtRisk: 4500, 
      estimatedCasualties: { min: 12, max: 28, mostLikely: 18 }, 
      spreadDirection: 75, 
      intensity: 70 
    }
  ]
};

// Enhanced weather data specific to Corbett region
export const corbettWeatherData = {
  current: {
    temperature: 34,
    humidity: 12,
    windSpeed: 28,
    windDirection: 65,
    pressure: 1008,
    visibility: 6, // Reduced due to haze
    uvIndex: 11, // Extreme
    dewPoint: -2, // Very dry
    fireWeatherIndex: 95 // Critical
  },
  forecast: [
    { hour: 1, temp: 35, humidity: 11, windSpeed: 30, fireRisk: 97 },
    { hour: 2, temp: 36, humidity: 10, windSpeed: 32, fireRisk: 98 },
    { hour: 3, temp: 37, humidity: 9, windSpeed: 35, fireRisk: 99 },
    { hour: 6, temp: 38, humidity: 8, windSpeed: 33, fireRisk: 99 },
    { hour: 12, temp: 36, humidity: 15, windSpeed: 25, fireRisk: 85 }
  ]
};

// Real-time sensor data simulation
export const corbettSensorNetwork = [
  {
    id: 'sensor-corbett-001',
    location: 'Dhikala Zone',
    lat: 29.5319,
    lng: 78.7718,
    type: 'Multi-sensor Station',
    status: 'active',
    lastReading: new Date(),
    data: {
      soilMoisture: 8, // Very dry
      leafMoisture: 12, // Critical
      smokeDetection: 0.02, // Trace amounts
      temperature: 34,
      humidity: 12,
      windSpeed: 28,
      co2Levels: 420,
      fireParticles: 0.001
    }
  },
  {
    id: 'sensor-corbett-002',
    location: 'Bijrani Zone',
    lat: 29.5500,
    lng: 78.8000,
    type: 'Fire Detection Camera',
    status: 'active',
    lastReading: new Date(),
    data: {
      thermalSignature: 'normal',
      smokeDetection: 0.01,
      visibilityIndex: 6,
      animalActivity: 'normal', // Animals fleeing would indicate fire
      humanActivity: 'high' // Tourist presence
    }
  }
];