// SMS Service with multiple provider support
export interface SMSProvider {
  name: string;
  sendSMS: (to: string, message: string, priority: string) => Promise<SMSResponse>;
}

export interface SMSResponse {
  success: boolean;
  messageId?: string;
  error?: string;
  cost?: number;
}

// Twilio Provider (International)
class TwilioProvider implements SMSProvider {
  name = 'Twilio';
  private accountSid: string;
  private authToken: string;
  private fromNumber: string;

  constructor(accountSid: string, authToken: string, fromNumber: string) {
    this.accountSid = accountSid;
    this.authToken = authToken;
    this.fromNumber = fromNumber;
  }

  async sendSMS(to: string, message: string, priority: string): Promise<SMSResponse> {
    try {
      const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${this.accountSid}/Messages.json`, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic ' + btoa(`${this.accountSid}:${this.authToken}`),
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: this.fromNumber,
          To: to,
          Body: message,
        }),
      });

      const data = await response.json();
      
      if (response.ok) {
        return {
          success: true,
          messageId: data.sid,
          cost: parseFloat(data.price) || 0.0075
        };
      } else {
        return {
          success: false,
          error: data.message || 'Failed to send SMS'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }
}

// TextLocal Provider (India)
class TextLocalProvider implements SMSProvider {
  name = 'TextLocal';
  private apiKey: string;
  private sender: string;

  constructor(apiKey: string, sender: string = 'SANJEV') {
    this.apiKey = apiKey;
    this.sender = sender;
  }

  async sendSMS(to: string, message: string, priority: string): Promise<SMSResponse> {
    try {
      // Convert +91-9876543210 to 919876543210
      const cleanNumber = to.replace(/[^0-9]/g, '');
      
      const response = await fetch('https://api.textlocal.in/send/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          apikey: this.apiKey,
          numbers: cleanNumber,
          message: message,
          sender: this.sender,
        }),
      });

      const data = await response.json();
      
      if (data.status === 'success') {
        return {
          success: true,
          messageId: data.messages[0]?.id,
          cost: data.cost || 0.02
        };
      } else {
        return {
          success: false,
          error: data.errors?.[0]?.message || 'Failed to send SMS'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }
}

// MSG91 Provider (India)
class MSG91Provider implements SMSProvider {
  name = 'MSG91';
  private authKey: string;
  private senderId: string;

  constructor(authKey: string, senderId: string = 'SANJEV') {
    this.authKey = authKey;
    this.senderId = senderId;
  }

  async sendSMS(to: string, message: string, priority: string): Promise<SMSResponse> {
    try {
      const cleanNumber = to.replace(/[^0-9]/g, '');
      
      const response = await fetch('https://api.msg91.com/api/sendhttp.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          authkey: this.authKey,
          mobiles: cleanNumber,
          message: message,
          sender: this.senderId,
          route: '4', // Transactional route
        }),
      });

      const data = await response.text();
      
      if (data.includes('success')) {
        return {
          success: true,
          messageId: data.split('|')[1],
          cost: 0.015
        };
      } else {
        return {
          success: false,
          error: data || 'Failed to send SMS'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }
}

// Fast2SMS Provider (India)
class Fast2SMSProvider implements SMSProvider {
  name = 'Fast2SMS';
  private apiKey: string;
  private senderId: string;

  constructor(apiKey: string, senderId: string = 'FSTSMS') {
    this.apiKey = apiKey;
    this.senderId = senderId;
  }

  async sendSMS(to: string, message: string, priority: string): Promise<SMSResponse> {
    try {
      const cleanNumber = to.replace(/[^0-9]/g, '').replace(/^91/, '');
      
      const response = await fetch('https://www.fast2sms.com/dev/bulkV2', {
        method: 'POST',
        headers: {
          'authorization': this.apiKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          route: 'v3',
          sender_id: this.senderId,
          message: message,
          language: 'english',
          flash: priority === 'critical' ? 1 : 0,
          numbers: cleanNumber,
        }),
      });

      const data = await response.json();
      
      if (data.return === true) {
        return {
          success: true,
          messageId: data.request_id,
          cost: 0.01
        };
      } else {
        return {
          success: false,
          error: data.message || 'Failed to send SMS'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }
}

// Main SMS Service
export class SMSService {
  private provider: SMSProvider;
  private fallbackProvider?: SMSProvider;

  constructor(provider: SMSProvider, fallbackProvider?: SMSProvider) {
    this.provider = provider;
    this.fallbackProvider = fallbackProvider;
  }

  async sendSMS(to: string, message: string, priority: 'low' | 'medium' | 'high' | 'critical'): Promise<SMSResponse> {
    // Add priority prefix to message
    const priorityEmojis = {
      low: '🟢',
      medium: '🟡', 
      high: '🟠',
      critical: '🚨'
    };

    const finalMessage = `${priorityEmojis[priority]} SANJEEVANI ALERT: ${message}`;

    // Try primary provider
    let result = await this.provider.sendSMS(to, finalMessage, priority);
    
    // If failed and we have fallback, try it
    if (!result.success && this.fallbackProvider) {
      console.log(`Primary provider (${this.provider.name}) failed, trying fallback (${this.fallbackProvider.name})`);
      result = await this.fallbackProvider.sendSMS(to, finalMessage, priority);
    }

    return result;
  }

  getProviderName(): string {
    return this.provider.name;
  }
}

// Factory function to create SMS service based on environment
export function createSMSService(): SMSService {
  // Check environment variables for different providers
  
  // Twilio (International)
  if (import.meta.env.VITE_TWILIO_ACCOUNT_SID && import.meta.env.VITE_TWILIO_AUTH_TOKEN) {
    const twilio = new TwilioProvider(
      import.meta.env.VITE_TWILIO_ACCOUNT_SID,
      import.meta.env.VITE_TWILIO_AUTH_TOKEN,
      import.meta.env.VITE_TWILIO_FROM_NUMBER
    );
    return new SMSService(twilio);
  }
  
  // TextLocal (India)
  if (import.meta.env.VITE_TEXTLOCAL_API_KEY) {
    const textLocal = new TextLocalProvider(
      import.meta.env.VITE_TEXTLOCAL_API_KEY,
      import.meta.env.VITE_TEXTLOCAL_SENDER || 'SANJEV'
    );
    return new SMSService(textLocal);
  }
  
  // MSG91 (India)
  if (import.meta.env.VITE_MSG91_AUTH_KEY) {
    const msg91 = new MSG91Provider(
      import.meta.env.VITE_MSG91_AUTH_KEY,
      import.meta.env.VITE_MSG91_SENDER_ID || 'SANJEV'
    );
    return new SMSService(msg91);
  }
  
  // Fast2SMS (India)
  if (import.meta.env.VITE_FAST2SMS_API_KEY) {
    const fast2sms = new Fast2SMSProvider(
      import.meta.env.VITE_FAST2SMS_API_KEY,
      import.meta.env.VITE_FAST2SMS_SENDER_ID || 'FSTSMS'
    );
    return new SMSService(fast2sms);
  }
  
  // Fallback to demo mode
  console.warn('No SMS provider configured. Using demo mode.');
  return new SMSService({
    name: 'Demo',
    sendSMS: async (to: string, message: string) => ({
      success: true,
      messageId: `demo-${Date.now()}`,
      cost: 0
    })
  });
}