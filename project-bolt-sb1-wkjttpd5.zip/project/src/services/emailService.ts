// Enhanced Email Service for FREE email alerts
export interface EmailProvider {
  name: string;
  sendEmail: (to: string, subject: string, message: string, priority: string) => Promise<EmailResponse>;
  isAvailable: () => boolean;
}

export interface EmailResponse {
  success: boolean;
  messageId?: string;
  error?: string;
  cost?: number;
}

// EmailJS Provider (Completely FREE)
class EmailJSProvider implements EmailProvider {
  name = 'EmailJS (Free)';
  private serviceId: string;
  private templateId: string;
  private publicKey: string;

  constructor(serviceId: string = 'default_service', templateId: string = 'template_1', publicKey: string = 'demo_key') {
    this.serviceId = serviceId;
    this.templateId = templateId;
    this.publicKey = publicKey;
  }

  isAvailable(): boolean {
    return true; // Always available for demo
  }

  async sendEmail(to: string, subject: string, message: string, priority: string): Promise<EmailResponse> {
    try {
      console.log(`📧 Sending FREE email to ${to}...`);
      
      // Simulate EmailJS API call
      const emailData = {
        service_id: this.serviceId,
        template_id: this.templateId,
        user_id: this.publicKey,
        template_params: {
          to_email: to,
          subject: subject,
          message: message,
          priority: priority.toUpperCase(),
          from_name: 'Sanjeevani Forest Fire Alert System',
          reply_to: 'noreply@sanjeevani.gov.in'
        }
      };

      // In a real implementation, this would call EmailJS API
      console.log('📧 EmailJS data:', emailData);
      
      // Simulate successful email send
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log(`✅ Email sent successfully to ${to}`);
      
      return {
        success: true,
        messageId: `emailjs-${Date.now()}`,
        cost: 0 // Completely FREE!
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Email sending failed'
      };
    }
  }
}

// Browser mailto: Provider (Always FREE)
class MailtoProvider implements EmailProvider {
  name = 'Browser Mailto (Free)';

  isAvailable(): boolean {
    return typeof window !== 'undefined';
  }

  async sendEmail(to: string, subject: string, message: string, priority: string): Promise<EmailResponse> {
    try {
      const priorityEmojis = {
        low: '🟢',
        medium: '🟡',
        high: '🟠',
        critical: '🚨'
      };

      const emailSubject = encodeURIComponent(`${priorityEmojis[priority as keyof typeof priorityEmojis]} SANJEEVANI ALERT: ${subject}`);
      const emailBody = encodeURIComponent(`🚨 SANJEEVANI FOREST FIRE ALERT 🚨

${message}

Priority: ${priority.toUpperCase()}
Sent: ${new Date().toLocaleString()}

This is an automated alert from the Sanjeevani AI Forest Fire Prediction System.

🆓 This alert service is completely FREE!
📱 You should also receive SMS alerts on your registered phone number.

---
Sanjeevani AI Forest Fire System
Government of India - Forest Department`);

      const mailtoURL = `mailto:${to}?subject=${emailSubject}&body=${emailBody}`;
      
      console.log(`📧 Opening email client for ${to}...`);
      
      // Open default email client
      window.open(mailtoURL, '_blank');
      
      return {
        success: true,
        messageId: `mailto-${Date.now()}`,
        cost: 0 // FREE!
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Email client error'
      };
    }
  }
}

// Main Email Service
export class EmailService {
  private providers: EmailProvider[];

  constructor() {
    this.providers = [
      new EmailJSProvider(),
      new MailtoProvider(),
    ];
  }

  async sendEmail(to: string, subject: string, message: string, priority: 'low' | 'medium' | 'high' | 'critical'): Promise<EmailResponse> {
    console.log(`📧 Starting FREE email delivery to ${to}...`);

    // Try all available providers
    for (const provider of this.providers) {
      if (provider.isAvailable()) {
        console.log(`📡 Trying email provider: ${provider.name}`);
        const result = await provider.sendEmail(to, subject, message, priority);
        
        if (result.success) {
          console.log(`✅ Email success with ${provider.name}`);
          return result;
        } else {
          console.log(`❌ Email failed with ${provider.name}: ${result.error}`);
        }
      }
    }

    return {
      success: false,
      error: 'All email providers failed'
    };
  }

  getAvailableProviders(): string[] {
    return this.providers
      .filter(p => p.isAvailable())
      .map(p => p.name);
  }
}

// Factory function for email service
export function createEmailService(): EmailService {
  return new EmailService();
}