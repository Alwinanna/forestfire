import React, { createContext, useContext, useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { useAuth } from './AuthContext';
import { createFreeSMSService, FreeSMSService } from '../services/freeSMSService';
import { createEmailService, EmailService } from '../services/emailService';

interface NotificationContextType {
  sendSMSAlert: (message: string, priority: 'low' | 'medium' | 'high' | 'critical') => Promise<void>;
  sendEmailAlert: (message: string, priority: 'low' | 'medium' | 'high' | 'critical') => Promise<void>;
  sendBothAlerts: (message: string, priority: 'low' | 'medium' | 'high' | 'critical') => Promise<void>;
  smsHistory: SMSAlert[];
  emailHistory: EmailAlert[];
  smsService: FreeSMSService;
  emailService: EmailService;
  availableProviders: string[];
}

interface SMSAlert {
  id: string;
  message: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  timestamp: Date;
  recipient: string;
  status: 'sending' | 'sent' | 'delivered' | 'failed';
  cost?: number;
  provider?: string;
  messageId?: string;
}

interface EmailAlert {
  id: string;
  message: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  timestamp: Date;
  recipient: string;
  status: 'sending' | 'sent' | 'delivered' | 'failed';
  cost?: number;
  provider?: string;
  messageId?: string;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [smsHistory, setSmsHistory] = useState<SMSAlert[]>([]);
  const [emailHistory, setEmailHistory] = useState<EmailAlert[]>([]);
  const [smsService] = useState(() => createFreeSMSService());
  const [emailService] = useState(() => createEmailService());
  const [availableProviders, setAvailableProviders] = useState<string[]>([]);

  useEffect(() => {
    const smsProviders = smsService.getAvailableProviders();
    const emailProviders = emailService.getAvailableProviders();
    setAvailableProviders([...smsProviders, ...emailProviders]);
  }, [smsService, emailService]);

  // Enhanced FREE SMS sending function
  const sendSMSAlert = async (message: string, priority: 'low' | 'medium' | 'high' | 'critical') => {
    if (!user) return;

    const smsAlert: SMSAlert = {
      id: `sms-${Date.now()}`,
      message,
      priority,
      timestamp: new Date(),
      recipient: user.phone,
      status: 'sending',
      provider: smsService.getProviderName()
    };

    // Add to history immediately
    setSmsHistory(prev => [smsAlert, ...prev.slice(0, 19)]); // Keep last 20

    try {
      // Send FREE SMS
      const result = await smsService.sendSMS(user.phone, message, priority);
      
      if (result.success) {
        // Update status to sent
        setSmsHistory(prev => prev.map(sms => 
          sms.id === smsAlert.id 
            ? { 
                ...sms, 
                status: 'sent',
                cost: result.cost || 0,
                messageId: result.messageId
              } 
            : sms
        ));

        // Show success toast
        const priorityColors = {
          low: '🟢',
          medium: '🟡',
          high: '🟠',
          critical: '🚨'
        };

        toast.success(
          `${priorityColors[priority]} FREE SMS Alert Sent!\n📱 Check your phone, WhatsApp, or browser notifications!`,
          {
            duration: 8000,
            style: {
              background: priority === 'critical' ? '#dc2626' : '#059669',
              color: 'white',
              maxWidth: '450px'
            }
          }
        );

        // Simulate delivery confirmation
        setTimeout(() => {
          setSmsHistory(prev => prev.map(sms => 
            sms.id === smsAlert.id ? { ...sms, status: 'delivered' } : sms
          ));
        }, Math.random() * 5000 + 2000);

      } else {
        // Update status to failed
        setSmsHistory(prev => prev.map(sms => 
          sms.id === smsAlert.id 
            ? { ...sms, status: 'failed' } 
            : sms
        ));

        toast.error(
          `❌ SMS Alert Failed: ${result.error}`,
          {
            duration: 8000,
            style: {
              background: '#dc2626',
              color: 'white',
            }
          }
        );
      }

    } catch (error) {
      // Handle network errors
      setSmsHistory(prev => prev.map(sms => 
        sms.id === smsAlert.id 
          ? { ...sms, status: 'failed' } 
          : sms
      ));

      toast.error(
        `❌ SMS Alert Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        {
          duration: 8000,
          style: {
            background: '#dc2626',
            color: 'white',
          }
        }
      );
    }
  };

  // Enhanced FREE Email sending function
  const sendEmailAlert = async (message: string, priority: 'low' | 'medium' | 'high' | 'critical') => {
    if (!user) return;

    const emailAlert: EmailAlert = {
      id: `email-${Date.now()}`,
      message,
      priority,
      timestamp: new Date(),
      recipient: user.email,
      status: 'sending',
      provider: 'EmailJS'
    };

    // Add to history immediately
    setEmailHistory(prev => [emailAlert, ...prev.slice(0, 19)]); // Keep last 20

    try {
      // Send FREE Email
      const result = await emailService.sendEmail(
        user.email, 
        'Forest Fire Alert', 
        message, 
        priority
      );
      
      if (result.success) {
        // Update status to sent
        setEmailHistory(prev => prev.map(email => 
          email.id === emailAlert.id 
            ? { 
                ...email, 
                status: 'sent',
                cost: result.cost || 0,
                messageId: result.messageId
              } 
            : email
        ));

        // Show success toast
        const priorityColors = {
          low: '🟢',
          medium: '🟡',
          high: '🟠',
          critical: '🚨'
        };

        toast.success(
          `${priorityColors[priority]} FREE Email Alert Sent!\n📧 Check your email inbox!`,
          {
            duration: 8000,
            style: {
              background: priority === 'critical' ? '#dc2626' : '#059669',
              color: 'white',
              maxWidth: '450px'
            }
          }
        );

        // Simulate delivery confirmation
        setTimeout(() => {
          setEmailHistory(prev => prev.map(email => 
            email.id === emailAlert.id ? { ...email, status: 'delivered' } : email
          ));
        }, Math.random() * 3000 + 1000);

      } else {
        // Update status to failed
        setEmailHistory(prev => prev.map(email => 
          email.id === emailAlert.id 
            ? { ...email, status: 'failed' } 
            : email
        ));

        toast.error(
          `❌ Email Alert Failed: ${result.error}`,
          {
            duration: 8000,
            style: {
              background: '#dc2626',
              color: 'white',
            }
          }
        );
      }

    } catch (error) {
      // Handle network errors
      setEmailHistory(prev => prev.map(email => 
        email.id === emailAlert.id 
          ? { ...email, status: 'failed' } 
          : email
      ));

      toast.error(
        `❌ Email Alert Error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        {
          duration: 8000,
          style: {
            background: '#dc2626',
            color: 'white',
          }
        }
      );
    }
  };

  // Send both SMS and Email alerts
  const sendBothAlerts = async (message: string, priority: 'low' | 'medium' | 'high' | 'critical') => {
    await Promise.all([
      sendSMSAlert(message, priority),
      sendEmailAlert(message, priority)
    ]);

    toast.success(
      `🚀 DUAL ALERT SENT! 📱📧\nBoth SMS and Email alerts sent for FREE!`,
      {
        duration: 10000,
        style: {
          background: '#059669',
          color: 'white',
          maxWidth: '450px'
        }
      }
    );
  };

  // Auto-send critical alerts for demo
  useEffect(() => {
    if (!user) return;

    const criticalAlerts = [
      "🚨 CRITICAL: Fire detected in Jim Corbett Core Zone. Immediate evacuation required.",
      "⚠️ HIGH ALERT: Wind speed increased to 35 km/h. Fire spread risk elevated.",
      "🔥 EMERGENCY: Tourist evacuation in progress. 150 people being moved to safety."
    ];

    let alertIndex = 0;
    const interval = setInterval(() => {
      if (alertIndex < criticalAlerts.length) {
        sendBothAlerts(criticalAlerts[alertIndex], 'critical');
        alertIndex++;
      } else {
        clearInterval(interval);
      }
    }, 90000); // Send every 90 seconds

    return () => clearInterval(interval);
  }, [user]);

  return (
    <NotificationContext.Provider value={{ 
      sendSMSAlert, 
      sendEmailAlert,
      sendBothAlerts,
      smsHistory,
      emailHistory,
      smsService,
      emailService,
      availableProviders
    }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};