import React, { createContext, useContext, useState, useEffect } from 'react';
import toast from 'react-hot-toast';

interface User {
  id: string;
  name: string;
  email: string;
  employeeId: string;
  role: 'admin' | 'firefighter' | 'observer' | 'analyst';
  department: string;
  clearanceLevel: number;
  avatar?: string;
  phone: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string, employeeId: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Government personnel database with phone numbers
const authorizedPersonnel: Record<string, { password: string; user: User }> = {
  'director@forest.gov.in': {
    password: 'ForestDir2024',
    user: {
      id: '1',
      name: 'Dr. Rajesh Kumar',
      email: 'director@forest.gov.in',
      employeeId: 'FD001',
      role: 'admin',
      department: 'Forest Department - Director',
      clearanceLevel: 5,
      avatar: '👨‍💼',
      phone: '+91-9876543210'
    }
  },
  'fireops@emergency.gov.in': {
    password: 'FireOps2024',
    user: {
      id: '2',
      name: 'Captain Priya Sharma',
      email: 'fireops@emergency.gov.in',
      employeeId: 'FO001',
      role: 'firefighter',
      department: 'Fire & Emergency Services',
      clearanceLevel: 4,
      avatar: '👩‍🚒',
      phone: '+91-9876543211'
    }
  },
  'analyst@isro.gov.in': {
    password: 'ISRO2024',
    user: {
      id: '3',
      name: 'Dr. Amit Singh',
      email: 'analyst@isro.gov.in',
      employeeId: 'IS001',
      role: 'analyst',
      department: 'ISRO - Satellite Analysis Division',
      clearanceLevel: 3,
      avatar: '🛰️',
      phone: '+91-9876543212'
    }
  },
  'observer@forest.gov.in': {
    password: 'Observer2024',
    user: {
      id: '4',
      name: 'Smt. Kavita Devi',
      email: 'observer@forest.gov.in',
      employeeId: 'OB001',
      role: 'observer',
      department: 'Field Operations - Uttarakhand',
      clearanceLevel: 2,
      avatar: '👨‍🔬',
      phone: '+91-9876543213'
    }
  }
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('sanjeevani_user_session');
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        // Verify session is still valid (less than 8 hours old)
        const sessionTime = new Date(userData.sessionStart);
        const now = new Date();
        const hoursDiff = (now.getTime() - sessionTime.getTime()) / (1000 * 60 * 60);
        
        if (hoursDiff < 8) {
          setUser(userData.user);
        } else {
          localStorage.removeItem('sanjeevani_user_session');
          toast.error('Session expired. Please login again.');
        }
      } catch (error) {
        localStorage.removeItem('sanjeevani_user_session');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string, employeeId: string): Promise<boolean> => {
    setLoading(true);
    
    // Simulate secure authentication delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const userRecord = authorizedPersonnel[email];
    
    if (!userRecord) {
      toast.error('🚫 Access Denied: Email not found in authorized personnel database');
      setLoading(false);
      return false;
    }

    if (userRecord.password !== password) {
      toast.error('🚫 Access Denied: Invalid sacred mantra (password)');
      setLoading(false);
      return false;
    }

    if (userRecord.user.employeeId !== employeeId.toUpperCase()) {
      toast.error('🚫 Access Denied: Guardian ID mismatch');
      setLoading(false);
      return false;
    }

    // Successful authentication
    const sessionData = {
      user: userRecord.user,
      sessionStart: new Date().toISOString(),
      lastActivity: new Date().toISOString()
    };

    setUser(userRecord.user);
    localStorage.setItem('sanjeevani_user_session', JSON.stringify(sessionData));
    
    toast.success(`🌿 Sacred Access Granted! Welcome ${userRecord.user.name}`, {
      duration: 5000,
      style: {
        background: 'linear-gradient(135deg, #059669, #10b981)',
        color: 'white',
        fontWeight: '600'
      }
    });
    
    setLoading(false);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('sanjeevani_user_session');
    toast.success('🙏 Sacred logout completed', {
      style: {
        background: 'linear-gradient(135deg, #0f766e, #059669)',
        color: 'white',
      }
    });
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};