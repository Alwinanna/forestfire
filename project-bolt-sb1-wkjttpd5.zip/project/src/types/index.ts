export interface FireRiskData {
  id: string;
  lat: number;
  lng: number;
  riskLevel: 'nil' | 'low' | 'moderate' | 'high' | 'critical';
  confidence: number;
  temperature: number;
  humidity: number;
  windSpeed: number;
  windDirection: number;
  vegetation: number;
  slope: number;
  humanActivity: number;
  lastUpdated: Date;
  shapExplanation: ShapExplanation;
}

export interface ShapExplanation {
  topFactors: Array<{
    factor: string;
    impact: number;
    description: string;
  }>;
  riskScore: number;
}

export interface PopulationImpact {
  estimatedAffected: number;
  settlements: number;
  infrastructure: Array<{
    type: string;
    count: number;
    risk: string;
  }>;
  evacuationTime: number;
  safeZones: Array<{
    lat: number;
    lng: number;
    capacity: number;
  }>;
}

export interface FireSpreadPrediction {
  timeHour: number;
  affectedArea: number;
  populationAtRisk: number;
  estimatedCasualties: {
    min: number;
    max: number;
    mostLikely: number;
  };
  spreadDirection: number;
  intensity: number;
}

export interface AlertData {
  id: string;
  level: 'warning' | 'critical' | 'emergency';
  location: string;
  message: string;
  timestamp: Date;
  acknowledged: boolean;
  estimatedImpact: PopulationImpact;
  predictions: FireSpreadPrediction[];
}