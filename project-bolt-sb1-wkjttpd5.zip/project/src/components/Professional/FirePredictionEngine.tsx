import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, 
  Zap, 
  Activity, 
  Target, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  Thermometer,
  Wind,
  Droplets,
  Eye,
  Satellite,
  Database,
  Cpu,
  BarChart3,
  LineChart,
  PieChart
} from 'lucide-react';
import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart as RechartsPieChart, Cell } from 'recharts';

interface FirePredictionData {
  timeHour: number;
  fireProbability: number;
  spreadArea: number;
  intensity: number;
  confidence: number;
  weatherFactor: number;
  terrainFactor: number;
  fuelFactor: number;
  humanFactor: number;
}

interface ModelPerformance {
  modelName: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  processingTime: number;
  lastTrained: Date;
  status: 'active' | 'training' | 'updating';
}

export const FirePredictionEngine: React.FC = () => {
  const [predictionData, setPredictionData] = useState<FirePredictionData[]>([]);
  const [modelPerformance, setModelPerformance] = useState<ModelPerformance[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('physics-informed-unet');
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [realTimeMode, setRealTimeMode] = useState(true);

  useEffect(() => {
    initializePredictionData();
    initializeModelPerformance();
    
    if (realTimeMode) {
      const interval = setInterval(() => {
        updatePredictions();
        setLastUpdate(new Date());
      }, 5000); // Update every 5 seconds

      return () => clearInterval(interval);
    }
  }, [realTimeMode, selectedModel]);

  const initializePredictionData = () => {
    const data: FirePredictionData[] = [];
    
    for (let hour = 1; hour <= 24; hour++) {
      // Simulate realistic fire spread progression
      const baseProbability = 0.3 + (hour * 0.02); // Increases over time
      const weatherVariation = Math.sin(hour / 24 * Math.PI * 2) * 0.1; // Daily weather cycle
      const randomVariation = (Math.random() - 0.5) * 0.1;
      
      data.push({
        timeHour: hour,
        fireProbability: Math.min(0.95, Math.max(0.05, baseProbability + weatherVariation + randomVariation)),
        spreadArea: Math.pow(hour, 1.3) * 0.8 + Math.random() * 0.5, // Non-linear spread
        intensity: Math.min(100, 60 + hour * 1.5 + Math.random() * 10),
        confidence: Math.max(70, 95 - hour * 0.5 + Math.random() * 5), // Confidence decreases over time
        weatherFactor: 0.7 + Math.random() * 0.3,
        terrainFactor: 0.6 + Math.random() * 0.4,
        fuelFactor: 0.8 + Math.random() * 0.2,
        humanFactor: 0.3 + Math.random() * 0.4
      });
    }
    
    setPredictionData(data);
  };

  const initializeModelPerformance = () => {
    const models: ModelPerformance[] = [
      {
        modelName: 'Physics-Informed U-NET',
        accuracy: 94.2,
        precision: 92.8,
        recall: 95.1,
        f1Score: 93.9,
        processingTime: 2.3,
        lastTrained: new Date(Date.now() - 86400000),
        status: 'active'
      },
      {
        modelName: 'LSTM Temporal Predictor',
        accuracy: 91.8,
        precision: 90.2,
        recall: 93.4,
        f1Score: 91.8,
        processingTime: 1.8,
        lastTrained: new Date(Date.now() - 172800000),
        status: 'active'
      },
      {
        modelName: 'Cellular Automata Simulator',
        accuracy: 89.5,
        precision: 87.9,
        recall: 91.2,
        f1Score: 89.5,
        processingTime: 3.1,
        lastTrained: new Date(Date.now() - 259200000),
        status: 'active'
      },
      {
        modelName: 'Quantum-Enhanced Predictor',
        accuracy: 96.7,
        precision: 95.8,
        recall: 97.3,
        f1Score: 96.5,
        processingTime: 4.2,
        lastTrained: new Date(Date.now() - 43200000),
        status: 'training'
      }
    ];
    
    setModelPerformance(models);
  };

  const updatePredictions = () => {
    setPredictionData(prev => prev.map(data => ({
      ...data,
      fireProbability: Math.min(0.95, Math.max(0.05, data.fireProbability + (Math.random() - 0.5) * 0.02)),
      intensity: Math.min(100, Math.max(0, data.intensity + (Math.random() - 0.5) * 2)),
      confidence: Math.min(99, Math.max(70, data.confidence + (Math.random() - 0.5) * 1))
    })));
  };

  const runPrediction = async () => {
    setIsProcessing(true);
    
    // Simulate AI model processing
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Update predictions with new data
    initializePredictionData();
    
    setIsProcessing(false);
  };

  const currentPrediction = predictionData[0] || {
    fireProbability: 0,
    intensity: 0,
    confidence: 0,
    spreadArea: 0
  };

  const factorData = [
    { name: 'Weather', value: currentPrediction.weatherFactor * 100, color: '#3b82f6' },
    { name: 'Terrain', value: currentPrediction.terrainFactor * 100, color: '#10b981' },
    { name: 'Fuel Load', value: currentPrediction.fuelFactor * 100, color: '#f59e0b' },
    { name: 'Human Activity', value: currentPrediction.humanFactor * 100, color: '#ef4444' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card-primary space-component">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-600 rounded-lg">
              <Brain className="text-white" size={24} />
            </div>
            <div>
              <h2 className="text-heading-2 font-bold text-white">🧠 AI FIRE PREDICTION ENGINE</h2>
              <p className="text-body-small text-slate-400">Physics-Informed Neural Networks with Real-Time Processing</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => setRealTimeMode(!realTimeMode)}
              className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                realTimeMode 
                  ? 'bg-green-600 hover:bg-green-700 text-white' 
                  : 'bg-slate-600 hover:bg-slate-700 text-white'
              }`}
            >
              {realTimeMode ? 'LIVE' : 'PAUSED'}
            </button>
            
            <button
              onClick={runPrediction}
              disabled={isProcessing}
              className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-lg font-semibold transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Zap size={16} />
                  Run Prediction
                </>
              )}
            </button>
          </div>
        </div>

        {/* Model Selection */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-slate-300 mb-2">Active AI Model</label>
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            className="w-full p-3 bg-slate-700/50 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value="physics-informed-unet">Physics-Informed U-NET (94.2% accuracy)</option>
            <option value="lstm-temporal">LSTM Temporal Predictor (91.8% accuracy)</option>
            <option value="cellular-automata">Cellular Automata Simulator (89.5% accuracy)</option>
            <option value="quantum-enhanced">Quantum-Enhanced Predictor (96.7% accuracy)</option>
          </select>
        </div>

        {/* Real-time Metrics */}
        <div className="grid-responsive grid-1-2-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-r from-red-600 to-red-700 rounded-lg p-4 text-white text-center"
          >
            <div className="text-2xl font-bold">{(currentPrediction.fireProbability * 100).toFixed(1)}%</div>
            <div className="text-sm opacity-90">Fire Probability</div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-r from-orange-600 to-orange-700 rounded-lg p-4 text-white text-center"
          >
            <div className="text-2xl font-bold">{currentPrediction.intensity.toFixed(0)}</div>
            <div className="text-sm opacity-90">Fire Intensity</div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-4 text-white text-center"
          >
            <div className="text-2xl font-bold">{currentPrediction.confidence.toFixed(0)}%</div>
            <div className="text-sm opacity-90">Model Confidence</div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-r from-green-600 to-green-700 rounded-lg p-4 text-white text-center"
          >
            <div className="text-2xl font-bold">{currentPrediction.spreadArea.toFixed(1)} km²</div>
            <div className="text-sm opacity-90">Predicted Spread</div>
          </motion.div>
        </div>
      </div>

      <div className="grid-responsive grid-1-2 gap-6">
        {/* Fire Probability Prediction Chart */}
        <div className="card-primary space-component">
          <h3 className="text-heading-3 font-bold text-white mb-4">24-Hour Fire Probability Forecast</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={predictionData.slice(0, 12)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="timeHour" 
                  stroke="#9ca3af"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#9ca3af" 
                  fontSize={12}
                  tickFormatter={(value) => `${(value * 100).toFixed(0)}%`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#f9fafb'
                  }}
                  formatter={(value: any) => [`${(value * 100).toFixed(1)}%`, 'Fire Probability']}
                />
                <Area 
                  type="monotone" 
                  dataKey="fireProbability" 
                  stroke="#dc2626" 
                  fill="#dc2626" 
                  fillOpacity={0.3}
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Contributing Factors */}
        <div className="card-primary space-component">
          <h3 className="text-heading-3 font-bold text-white mb-4">Contributing Factors Analysis</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={factorData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="name" 
                  stroke="#9ca3af"
                  fontSize={12}
                  angle={-45}
                  textAnchor="end"
                  height={80}
                />
                <YAxis 
                  stroke="#9ca3af" 
                  fontSize={12}
                  tickFormatter={(value) => `${value}%`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                    color: '#f9fafb'
                  }}
                  formatter={(value: any) => [`${value.toFixed(1)}%`, 'Contribution']}
                />
                <Bar dataKey="value" fill="#8884d8" radius={[4, 4, 0, 0]}>
                  {factorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Model Performance Dashboard */}
      <div className="card-primary space-component">
        <h3 className="text-heading-3 font-bold text-white mb-4">AI Model Performance Dashboard</h3>
        <div className="grid-responsive grid-1-2">
          {modelPerformance.map((model, index) => (
            <motion.div
              key={model.modelName}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`bg-slate-700/50 rounded-lg p-4 border cursor-pointer transition-all ${
                selectedModel.includes(model.modelName.toLowerCase().replace(/[^a-z]/g, '-')) 
                  ? 'border-purple-500 bg-purple-900/20' 
                  : 'border-slate-600 hover:border-slate-500'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-bold text-white">{model.modelName}</h4>
                  <p className="text-sm text-slate-400">Last trained: {model.lastTrained.toLocaleDateString()}</p>
                </div>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  model.status === 'active' ? 'bg-green-100 text-green-800' :
                  model.status === 'training' ? 'bg-blue-100 text-blue-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {model.status.toUpperCase()}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-green-400">{model.accuracy}%</div>
                  <div className="text-xs text-slate-400">Accuracy</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-400">{model.precision}%</div>
                  <div className="text-xs text-slate-400">Precision</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-orange-400">{model.recall}%</div>
                  <div className="text-xs text-slate-400">Recall</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-purple-400">{model.f1Score}%</div>
                  <div className="text-xs text-slate-400">F1-Score</div>
                </div>
              </div>

              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-400">Processing Time:</span>
                <span className="font-bold text-white">{model.processingTime}s</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Fire Spread Simulation */}
      <div className="card-primary space-component">
        <h3 className="text-heading-3 font-bold text-white mb-4">Fire Spread Area Prediction</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <RechartsLineChart data={predictionData.slice(0, 12)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="timeHour" 
                stroke="#9ca3af"
                fontSize={12}
              />
              <YAxis 
                stroke="#9ca3af" 
                fontSize={12}
                tickFormatter={(value) => `${value} km²`}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  border: '1px solid #374151',
                  borderRadius: '8px',
                  color: '#f9fafb'
                }}
                formatter={(value: any) => [`${value.toFixed(1)} km²`, 'Spread Area']}
              />
              <Line 
                type="monotone" 
                dataKey="spreadArea" 
                stroke="#f59e0b" 
                strokeWidth={3}
                dot={{ fill: '#f59e0b', strokeWidth: 2, r: 6 }}
              />
            </RechartsLineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Technical Implementation Details */}
      <div className="card-primary space-component">
        <h3 className="text-heading-3 font-bold text-white mb-4">🔬 Technical Implementation</h3>
        <div className="grid-responsive grid-1-2-3">
          <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-600">
            <h4 className="font-semibold text-blue-400 mb-2 flex items-center gap-2">
              <Brain size={16} />
              Physics-Informed Neural Networks
            </h4>
            <ul className="space-y-1 text-sm text-blue-200">
              <li>• Heat transfer equation constraints</li>
              <li>• Wind dynamics physics modeling</li>
              <li>• Fuel consumption rate calculations</li>
              <li>• Bayesian uncertainty quantification</li>
            </ul>
          </div>
          
          <div className="bg-green-900/30 rounded-lg p-4 border border-green-600">
            <h4 className="font-semibold text-green-400 mb-2 flex items-center gap-2">
              <Database size={16} />
              Multi-Source Data Fusion
            </h4>
            <ul className="space-y-1 text-sm text-green-200">
              <li>• ISRO satellite imagery (INSAT-3D, Cartosat-3)</li>
              <li>• Weather station networks (IMD, MOSDAC)</li>
              <li>• Terrain data (30m DEM, slope, aspect)</li>
              <li>• Real-time sensor networks</li>
            </ul>
          </div>
          
          <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-600">
            <h4 className="font-semibold text-purple-400 mb-2 flex items-center gap-2">
              <Cpu size={16} />
              Advanced Processing
            </h4>
            <ul className="space-y-1 text-sm text-purple-200">
              <li>• Real-time cloud correction (99.9%)</li>
              <li>• Quantum-enhanced pattern recognition</li>
              <li>• Cellular automata fire spread simulation</li>
              <li>• 5-second update frequency</li>
            </ul>
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="card-primary space-component">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-heading-3 font-bold text-white mb-2">System Status</h3>
            <p className="text-body-small text-slate-400">Last updated: {lastUpdate.toLocaleString()}</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="text-green-500" size={20} />
              <span className="text-green-400 font-semibold">All Models Operational</span>
            </div>
            <div className="flex items-center gap-2">
              <Activity className="text-blue-500" size={20} />
              <span className="text-blue-400 font-semibold">Real-Time Processing</span>
            </div>
            <div className="flex items-center gap-2">
              <Satellite className="text-purple-500" size={20} />
              <span className="text-purple-400 font-semibold">ISRO Data Live</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};